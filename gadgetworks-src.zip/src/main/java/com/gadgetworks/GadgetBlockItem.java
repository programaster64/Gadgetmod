package com.gadgetworks;

import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class GadgetBlockItem extends BlockItem {
    public GadgetBlockItem(Block block, Settings settings) { super(block, settings); }

    @Override
    public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, TooltipContext context) {
        byte[] v = Gadgets.readVoxels(stack);
        if (v != null) tooltip.add(Text.literal("Piezas: " + Gadgets.count(v)).formatted(Formatting.GRAY));
    }
}
