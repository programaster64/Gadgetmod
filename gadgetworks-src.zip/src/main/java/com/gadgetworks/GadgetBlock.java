package com.gadgetworks;

import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class GadgetBlock extends BlockWithEntity {
    public GadgetBlock(Settings settings) { super(settings); }

    @Override
    public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return new GadgetBlockEntity(pos, state);
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockView world, BlockPos pos,
                                        net.minecraft.block.ShapeContext context) {
        if (world.getBlockEntity(pos) instanceof GadgetBlockEntity be) {
            return be.getGadgetShape();
        }
        return VoxelShapes.empty();
    }

    @Override
    public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos,
                                      net.minecraft.block.ShapeContext context) {
        if (world.getBlockEntity(pos) instanceof GadgetBlockEntity be) {
            VoxelShape shape = be.getGadgetShape();
            // Mantiene el bloque seleccionable incluso si el diseño está vacío.
            return shape.isEmpty() ? VoxelShapes.fullCube() : shape;
        }
        return VoxelShapes.fullCube();
    }

    @Override
    public BlockRenderType getRenderType(BlockState state) { return BlockRenderType.INVISIBLE; }

    @Override
    public void onPlaced(World world, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.onPlaced(world, pos, state, placer, stack);
        if (!world.isClient) world.updateListeners(pos, state, state, 3);
    }

    @Override
    public ItemStack getPickStack(BlockView world, BlockPos pos, BlockState state) {
        ItemStack stack = new ItemStack(this);
        if (world.getBlockEntity(pos) instanceof GadgetBlockEntity be) {
            NbtCompound tag = new NbtCompound();
            tag.putByteArray("Voxels", be.getVoxels());
            stack.getOrCreateNbt().put("BlockEntityTag", tag);
        }
        return stack;
    }
}
