package com.gadgetworks;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.util.math.BlockPos;

public class GadgetBlockEntity extends BlockEntity {
    private byte[] voxels = new byte[Gadgets.VOLUME];

    public GadgetBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlocks.GADGET_BE, pos, state);
    }

    public byte[] getVoxels() { return voxels; }

    @Override
    protected void writeNbt(NbtCompound nbt) {
        super.writeNbt(nbt);
        nbt.putByteArray("Voxels", voxels);
    }

    @Override
    public void readNbt(NbtCompound nbt) {
        super.readNbt(nbt);
        byte[] b = nbt.getByteArray("Voxels");
        if (b.length == Gadgets.VOLUME) voxels = b;
    }

    @Override
    public Packet<ClientPlayPacketListener> toUpdatePacket() { return BlockEntityUpdateS2CPacket.create(this); }

    @Override
    public NbtCompound toInitialChunkDataNbt() { return createNbt(); }
}
