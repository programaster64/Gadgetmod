package com.gadgetworks;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;

public class GadgetBlockEntity extends BlockEntity {
    private byte[] voxels = new byte[Gadgets.VOLUME];
    private VoxelShape cachedShape;

    public GadgetBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlocks.GADGET_BE, pos, state);
    }

    public byte[] getVoxels() { return voxels; }

    /** Construye una hitbox a partir de los vóxeles ocupados y la conserva en caché. */
    public VoxelShape getGadgetShape() {
        if (cachedShape != null) return cachedShape;

        VoxelShape shape = VoxelShapes.empty();
        final double unit = 1.0 / 16.0;

        // Agrupa vóxeles contiguos en X para reducir el número de cajas de colisión.
        for (int y = 0; y < 16; y++) {
            for (int z = 0; z < 16; z++) {
                int x = 0;
                while (x < 16) {
                    while (x < 16 && voxels[Gadgets.idx(x, y, z)] == 0) x++;
                    if (x >= 16) break;
                    int start = x;
                    while (x < 16 && voxels[Gadgets.idx(x, y, z)] != 0) x++;
                    VoxelShape run = VoxelShapes.cuboid(new Box(
                            start * unit, y * unit, z * unit,
                            x * unit, (y + 1) * unit, (z + 1) * unit));
                    shape = VoxelShapes.union(shape, run);
                }
            }
        }

        cachedShape = shape.simplify();
        return cachedShape;
    }

    @Override
    protected void writeNbt(NbtCompound nbt) {
        super.writeNbt(nbt);
        nbt.putByteArray("Voxels", voxels);
    }

    @Override
    public void readNbt(NbtCompound nbt) {
        super.readNbt(nbt);
        byte[] b = nbt.getByteArray("Voxels");
        if (b.length == Gadgets.VOLUME) voxels = b;
        cachedShape = null;
    }

    @Override
    public Packet<ClientPlayPacketListener> toUpdatePacket() { return BlockEntityUpdateS2CPacket.create(this); }

    @Override
    public NbtCompound toInitialChunkDataNbt() { return createNbt(); }
}
