package com.gadgetworks;

import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModBlocks {
    public static final Block WORKBENCH = new GadgetWorkbenchBlock(FabricBlockSettings.copyOf(Blocks.SMITHING_TABLE));
    public static final Block GADGET_BLOCK = new GadgetBlock(FabricBlockSettings.copyOf(Blocks.IRON_BLOCK).nonOpaque().strength(2.0f));
    public static BlockEntityType<GadgetBlockEntity> GADGET_BE;

    public static void register() {
        Registry.register(Registries.BLOCK, new Identifier(Gadgets.ID, "gadget_workbench"), WORKBENCH);
        Registry.register(Registries.BLOCK, new Identifier(Gadgets.ID, "gadget_block"), GADGET_BLOCK);
        GADGET_BE = Registry.register(Registries.BLOCK_ENTITY_TYPE, new Identifier(Gadgets.ID, "gadget_block"),
                FabricBlockEntityTypeBuilder.create(GadgetBlockEntity::new, GADGET_BLOCK).build());
    }
}
