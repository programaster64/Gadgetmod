package com.gadgetworks;

import java.util.function.Consumer;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class GadgetWorkbenchBlock extends Block {
    /** Lo asigna el cliente para abrir la pantalla. */
    public static Consumer<BlockPos> OPEN_HOOK = p -> {};

    public GadgetWorkbenchBlock(Settings settings) { super(settings); }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
        if (world.isClient) OPEN_HOOK.accept(pos);
        return ActionResult.success(world.isClient);
    }
}
