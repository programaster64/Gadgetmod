package com.gadgetworks;

import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.Identifier;

public final class Gadgets {
    public static final String ID = "gadgetworks";
    public static final int VOLUME = 4096;
    public static final Identifier CREATE = new Identifier(ID, "create");

    /** Valores de voxel: 0 = vacio, 1..7 = pieza. */
    public static final int PIECES = 7;
    public static final int GLUE = 6; // indice (0-based) del pegamento
    public static final String[] PIECE_IDS = {
        "carcasa", "procesador", "videochip", "pantalla", "motor", "rotor", "pegamento"
    };
    public static final String[] NAMES = {
        "Carcasa", "Procesador", "Videochip", "Pantalla", "Motor", "Rotor", "Pegamento"
    };

    private Gadgets() {}

    public static int idx(int x, int y, int z) { return (y << 8) | (z << 4) | x; }

    public static boolean solid(byte[] v, int x, int y, int z) {
        return x >= 0 && y >= 0 && z >= 0 && x < 16 && y < 16 && z < 16 && v[idx(x, y, z)] != 0;
    }

    public static int count(byte[] v) {
        int n = 0;
        for (byte b : v) if (b != 0) n++;
        return n;
    }

    /** Coste en lingotes de hierro: 1 por cada 64 piezas. */
    public static int cost(int count) { return (count + 63) / 64; }

    /** Todas las piezas deben estar unidas cara con cara (el pegamento sirve de puente). */
    public static boolean isConnected(byte[] v) {
        int start = -1, total = 0;
        for (int i = 0; i < VOLUME; i++) {
            if (v[i] != 0) { total++; if (start < 0) start = i; }
        }
        if (total == 0) return false;
        boolean[] seen = new boolean[VOLUME];
        int[] stack = new int[VOLUME];
        int sp = 0, reached = 0;
        stack[sp++] = start;
        seen[start] = true;
        final int[] dx = {1, -1, 0, 0, 0, 0}, dy = {0, 0, 1, -1, 0, 0}, dz = {0, 0, 0, 0, 1, -1};
        while (sp > 0) {
            int i = stack[--sp];
            reached++;
            int x = i & 15, z = (i >> 4) & 15, y = i >> 8;
            for (int d = 0; d < 6; d++) {
                int nx = x + dx[d], ny = y + dy[d], nz = z + dz[d];
                if (nx < 0 || ny < 0 || nz < 0 || nx > 15 || ny > 15 || nz > 15) continue;
                int j = idx(nx, ny, nz);
                if (v[j] != 0 && !seen[j]) { seen[j] = true; stack[sp++] = j; }
            }
        }
        return reached == total;
    }

    public static byte[] readVoxels(ItemStack s) {
        NbtCompound n = s.getNbt();
        if (n != null && n.contains("BlockEntityTag", 10)) {
            byte[] b = n.getCompound("BlockEntityTag").getByteArray("Voxels");
            if (b.length == VOLUME) return b;
        }
        return null;
    }
}
