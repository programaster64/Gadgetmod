package com.gadgetworks;

import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.Identifier;

public final class Gadgets {
    public static final String ID = "gadgetworks";
    public static final int VOLUME = 4096;
    public static final Identifier CREATE = new Identifier(ID, "create");

    public static final int[] COLORS = {
        0xF9FFFE, 0x9D9D97, 0x1D1D21, 0xB02E26, 0xF9801D, 0xFED83D, 0x80C71F, 0x5E7C16,
        0x169C9C, 0x3AB3DA, 0x3C44AA, 0x8932B8, 0xC74EBD, 0xF38BAA, 0x835432, 0xB4B9BF
    };
    public static final String[] NAMES = {
        "Blanco", "Gris", "Negro", "Rojo", "Naranja", "Amarillo", "Lima", "Verde",
        "Cian", "Celeste", "Azul", "Violeta", "Magenta", "Rosa", "Marron", "Metal"
    };

    private Gadgets() {}

    public static int idx(int x, int y, int z) { return (y << 8) | (z << 4) | x; }

    public static boolean solid(byte[] v, int x, int y, int z) {
        return x >= 0 && y >= 0 && z >= 0 && x < 16 && y < 16 && z < 16 && v[idx(x, y, z)] != 0;
    }

    public static int count(byte[] v) {
        int n = 0;
        for (byte b : v) if (b != 0) n++;
        return n;
    }

    /** Coste en lingotes de hierro: 1 por cada 64 piezas. */
    public static int cost(int count) { return (count + 63) / 64; }

    public static byte[] readVoxels(ItemStack s) {
        NbtCompound n = s.getNbt();
        if (n != null && n.contains("BlockEntityTag", 10)) {
            byte[] b = n.getCompound("BlockEntityTag").getByteArray("Voxels");
            if (b.length == VOLUME) return b;
        }
        return null;
    }
}
