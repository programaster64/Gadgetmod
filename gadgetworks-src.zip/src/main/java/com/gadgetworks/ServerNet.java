
package com.gadgetworks;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class ServerNet {
    public static void init() {
        ServerPlayNetworking.registerGlobalReceiver(
                Gadgets.CREATE,
                (server, player, handler, buf, sender) -> {

                    BlockPos pos = buf.readBlockPos();
                    boolean asBlock = buf.readBoolean();
                    byte[] voxels = buf.readByteArray(Gadgets.VOLUME);
                    String program = buf.readString(GadgetProgram.MAX_LENGTH);

                    server.execute(() ->
                            handle(player, pos, asBlock, voxels, program));
                });
    }

    private static void handle(
            ServerPlayerEntity player,
            BlockPos pos,
            boolean asBlock,
            byte[] voxels,
            String program) {

        if (voxels.length != Gadgets.VOLUME) return;

        if (player.squaredDistanceTo(Vec3d.ofCenter(pos)) > 64) return;

        if (!player.getWorld().getBlockState(pos)
                .isOf(ModBlocks.WORKBENCH)) return;

        int count = 0;

        for (byte value : voxels) {
            if (value < 0 || value > Gadgets.PIECES) return;
            if (value != 0) count++;
        }

        if (count == 0) return;

        if (!Gadgets.isConnected(voxels)) {
            player.sendMessage(
                    Text.literal("Hay piezas sueltas: unelas con pegamento."),
                    true);
            return;
        }

        if (!program.isBlank()
                && !GadgetProgram.validate(program, voxels)) {
            player.sendMessage(
                    Text.literal("Programa inválido o falta el procesador/videochip necesario."),
                    true);
            return;
        }

        int cost = Gadgets.cost(count);

        if (!player.isCreative()) {
            if (player.getInventory().count(Items.IRON_INGOT) < cost) {
                player.sendMessage(
                        Text.literal("Necesitas " + cost + " lingotes de hierro."),
                        true);
                return;
            }

            int left = cost;

            for (int i = 0;
                    i < player.getInventory().size() && left > 0;
                    i++) {

                ItemStack stack = player.getInventory().getStack(i);

                if (stack.isOf(Items.IRON_INGOT)) {
                    int take = Math.min(left, stack.getCount());
                    stack.decrement(take);
                    left -= take;
                }
            }
        }

        ItemStack output = new ItemStack(
                asBlock ? ModItems.GADGET_BLOCK : ModItems.GADGET);

        NbtCompound blockTag = new NbtCompound();
        blockTag.putByteArray("Voxels", voxels);

        output.getOrCreateNbt().put("BlockEntityTag", blockTag);
        output.getOrCreateNbt().putString("Program", program);

        player.getInventory().offerOrDrop(output);

        player.getWorld().playSound(
                null, pos,
                SoundEvents.BLOCK_ANVIL_USE,
                SoundCategory.BLOCKS,
                1.0f, 1.2f);
    }
}
