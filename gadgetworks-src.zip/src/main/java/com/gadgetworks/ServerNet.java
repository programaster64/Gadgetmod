package com.gadgetworks;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class ServerNet {
    public static void init() {
        ServerPlayNetworking.registerGlobalReceiver(Gadgets.CREATE, (server, player, handler, buf, sender) -> {
            BlockPos pos = buf.readBlockPos();
            boolean asBlock = buf.readBoolean();
            byte[] voxels = buf.readByteArray(Gadgets.VOLUME);
            server.execute(() -> handle(player, pos, asBlock, voxels));
        });
    }

    private static void handle(ServerPlayerEntity player, BlockPos pos, boolean asBlock, byte[] v) {
        if (v.length != Gadgets.VOLUME) return;
        if (player.squaredDistanceTo(Vec3d.ofCenter(pos)) > 64) return;
        if (!player.getWorld().getBlockState(pos).isOf(ModBlocks.WORKBENCH)) return;

        int count = 0;
        for (byte b : v) {
            if (b < 0 || b > 16) return;
            if (b != 0) count++;
        }
        if (count == 0) return;

        int cost = Gadgets.cost(count);
        if (!player.isCreative()) {
            if (player.getInventory().count(Items.IRON_INGOT) < cost) {
                player.sendMessage(Text.literal("Necesitas " + cost + " lingotes de hierro."), true);
                return;
            }
            int left = cost;
            for (int i = 0; i < player.getInventory().size() && left > 0; i++) {
                ItemStack s = player.getInventory().getStack(i);
                if (s.isOf(Items.IRON_INGOT)) {
                    int take = Math.min(left, s.getCount());
                    s.decrement(take);
                    left -= take;
                }
            }
        }

        ItemStack out = new ItemStack(asBlock ? ModItems.GADGET_BLOCK : ModItems.GADGET);
        NbtCompound tag = new NbtCompound();
        tag.putByteArray("Voxels", v);
        out.getOrCreateNbt().put("BlockEntityTag", tag);
        player.getInventory().offerOrDrop(out);
        player.getWorld().playSound(null, pos, SoundEvents.BLOCK_ANVIL_USE, SoundCategory.BLOCKS, 1f, 1.2f);
    }
}
