package com.gadgetworks;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModItems {
    public static final Item WORKBENCH = new BlockItem(ModBlocks.WORKBENCH, new FabricItemSettings());
    public static final Item GADGET = new GadgetItem(new FabricItemSettings().maxCount(1));
    public static final Item GADGET_BLOCK = new GadgetBlockItem(ModBlocks.GADGET_BLOCK, new FabricItemSettings().maxCount(1));

    public static void register() {
        Registry.register(Registries.ITEM, new Identifier(Gadgets.ID, "gadget_workbench"), WORKBENCH);
        Registry.register(Registries.ITEM, new Identifier(Gadgets.ID, "gadget"), GADGET);
        Registry.register(Registries.ITEM, new Identifier(Gadgets.ID, "gadget_block"), GADGET_BLOCK);
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FUNCTIONAL).register(e -> e.add(WORKBENCH));
    }
}
