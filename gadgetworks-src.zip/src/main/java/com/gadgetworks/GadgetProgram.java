
package com.gadgetworks;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

public final class GadgetProgram {
    public static final int MAX_LINES = 16;
    public static final int MAX_LENGTH = 1024;

    private GadgetProgram() {}

    private static boolean hasPiece(byte[] voxels, int piece) {
        for (byte value : voxels) {
            if (value == piece) return true;
        }
        return false;
    }

    private static boolean between(int n, int min, int max) {
        return n >= min && n <= max;
    }

    public static boolean validate(String source, byte[] voxels) {
        if (source == null || source.length() > MAX_LENGTH) return false;
        if (voxels == null || voxels.length != Gadgets.VOLUME) return false;

        boolean processor = hasPiece(voxels, 2);
        boolean video = hasPiece(voxels, 3);

        String[] lines = source.split("\\R", -1);
        if (lines.length > MAX_LINES) return false;

        for (String raw : lines) {
            String line = raw.trim();
            if (line.isEmpty()) continue;

            if (!validCommand(line, processor, video, false)) {
                return false;
            }
        }

        return true;
    }

    private static boolean validCommand(
            String line, boolean processor, boolean video, boolean nested) {

        if (!processor) return false;

        String[] p = line.split("\\s+", 4);

        try {
            switch (p[0].toLowerCase()) {
                case "mensaje":
                    return p.length >= 2;

                case "mostrar":
                    return video && p.length >= 2;

                case "curar":
                    return p.length == 2
                            && between(Integer.parseInt(p[1]), 1, 20);

                case "vida":
                    return p.length == 1;

                case "sonido":
                    return p.length == 2
                            && (p[1].equals("click")
                            || p[1].equals("exito")
                            || p[1].equals("error"));

                case "efecto":
                    return p.length == 4
                            && (p[1].equals("velocidad")
                            || p[1].equals("salto")
                            || p[1].equals("fuerza"))
                            && between(Integer.parseInt(p[2]), 1, 60)
                            && between(Integer.parseInt(p[3]), 1, 2);

                case "si_vida_menor":
                    if (nested || p.length < 3) return false;

                    int limit = Integer.parseInt(p[1]);
                    if (!between(limit, 1, 20)) return false;

                    String nestedCommand =
                            line.substring(line.indexOf(p[2]));

                    return validCommand(
                            nestedCommand, processor, video, true);

                default:
                    return false;
            }
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static void run(
            String source, byte[] voxels, ServerPlayerEntity player) {

        if (!validate(source, voxels)) {
            player.sendMessage(
                    Text.literal("Programa inválido o falta el procesador."),
                    true);
            return;
        }

        for (String raw : source.split("\\R")) {
            String line = raw.trim();

            if (!line.isEmpty()) {
                execute(line, player);
            }
        }
    }

    private static void execute(
            String line, ServerPlayerEntity player) {

        String[] p = line.split("\\s+", 4);

        switch (p[0].toLowerCase()) {
            case "mensaje":
                player.sendMessage(
                        Text.literal(line.substring(line.indexOf(p[1]))),
                        false);
                break;

            case "mostrar":
                player.sendMessage(
                        Text.literal(line.substring(line.indexOf(p[1]))),
                        true);
                break;

            case "curar":
                player.heal(Integer.parseInt(p[1]));
                break;

            case "vida":
                player.sendMessage(
                        Text.literal("Vida: "
                                + Math.round(player.getHealth())
                                + "/"
                                + Math.round(player.getMaxHealth())),
                        true);
                break;

            case "sonido":
                if (p[1].equals("exito")) {
                    player.getWorld().playSound(
                            null, player.getX(), player.getY(), player.getZ(),
                            SoundEvents.ENTITY_PLAYER_LEVELUP,
                            SoundCategory.PLAYERS, 1.0f, 1.0f);
                } else if (p[1].equals("error")) {
                    player.getWorld().playSound(
                            null, player.getX(), player.getY(), player.getZ(),
                            SoundEvents.BLOCK_NOTE_BLOCK_BASS,
                            SoundCategory.PLAYERS, 1.0f, 1.0f);
                } else {
                    player.getWorld().playSound(
                            null, player.getX(), player.getY(), player.getZ(),
                            SoundEvents.UI_BUTTON_CLICK,
                            SoundCategory.PLAYERS, 1.0f, 1.0f);
                }
                break;

            case "efecto":
                int seconds = Integer.parseInt(p[2]);
                int level = Integer.parseInt(p[3]);

                if (p[1].equals("velocidad")) {
                    player.addStatusEffect(new StatusEffectInstance(
                            StatusEffects.SPEED, seconds * 20, level - 1));
                } else if (p[1].equals("salto")) {
                    player.addStatusEffect(new StatusEffectInstance(
                            StatusEffects.JUMP_BOOST, seconds * 20, level - 1));
                } else if (p[1].equals("fuerza")) {
                    player.addStatusEffect(new StatusEffectInstance(
                            StatusEffects.STRENGTH, seconds * 20, level - 1));
                }
                break;

            case "si_vida_menor":
                int limit = Integer.parseInt(p[1]);

                if (player.getHealth() < limit) {
                    execute(line.substring(line.indexOf(p[2])), player);
                }
                break;
        }
    }
}
