package com.gadgetworks;

import java.util.List;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class GadgetItem extends Item {
    public GadgetItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(
            World world, PlayerEntity user, Hand hand) {

        ItemStack stack = user.getStackInHand(hand);

        if (!world.isClient && user instanceof ServerPlayerEntity) {
            byte[] voxels = Gadgets.readVoxels(stack);
            String program = stack.getOrCreateNbt().getString("Program");

            if (voxels != null && !program.isBlank()) {
                GadgetProgram.run(
                        program, voxels, (ServerPlayerEntity) user);
            } else {
                user.sendMessage(
                        Text.literal("Este gadget no tiene un programa instalado."),
                        true);
            }
        }

        return new TypedActionResult<>(net.minecraft.util.ActionResult.SUCCESS, stack);
    }

    @Override
    public void appendTooltip(
            ItemStack stack,
            @Nullable World world,
            List<Text> tooltip,
            TooltipContext context) {

        byte[] voxels = Gadgets.readVoxels(stack);

        if (voxels != null) {
            tooltip.add(Text.literal(
                    "Piezas: " + Gadgets.count(voxels))
                    .formatted(Formatting.GRAY));
        }

        if (stack.hasNbt()
                && !stack.getNbt().getString("Program").isBlank()) {
            tooltip.add(Text.literal("Programa instalado")
                    .formatted(Formatting.GREEN));
        }
    }
}
