package com.gadgetworks;

import java.util.List;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class GadgetItem extends Item {
    public GadgetItem(Settings settings) { super(settings); }

    @Override
    public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, TooltipContext context) {
        byte[] v = Gadgets.readVoxels(stack);
        if (v != null) tooltip.add(Text.literal("Piezas: " + Gadgets.count(v)).formatted(Formatting.GRAY));
    }
}
