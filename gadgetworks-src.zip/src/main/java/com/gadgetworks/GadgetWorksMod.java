package com.gadgetworks;

import net.fabricmc.api.ModInitializer;

public class GadgetWorksMod implements ModInitializer {
    @Override
    public void onInitialize() {
        ModBlocks.register();
        ModItems.register();
        ServerNet.init();
    }
}
