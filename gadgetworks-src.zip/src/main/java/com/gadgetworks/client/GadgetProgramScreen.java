
package com.gadgetworks.client;

import com.gadgetworks.GadgetProgram;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public class GadgetProgramScreen extends Screen {
    private final Screen parent;
    private final String initial;
    private final java.util.function.Consumer<String> onSave;

    private final TextFieldWidget[] lines = new TextFieldWidget[8];
    private String status = "";

    public GadgetProgramScreen(
            Screen parent,
            String initial,
            java.util.function.Consumer<String> onSave) {
        super(Text.literal("Programar chip"));
        this.parent = parent;
        this.initial = initial == null ? "" : initial;
        this.onSave = onSave;
    }

    @Override
    protected void init() {
        int w = Math.min(300, width - 30);
        int x = (width - w) / 2;
        String[] saved = initial.split("\\R", -1);

        for (int i = 0; i < lines.length; i++) {
            lines[i] = new TextFieldWidget(
                    textRenderer, x, 48 + i * 22, w, 20,
                    Text.literal("Instrucción " + (i + 1)));

            lines[i].setMaxLength(128);

            if (i < saved.length) {
                lines[i].setText(saved[i]);
            }

            addSelectableChild(lines[i]);
        }

        setInitialFocus(lines[0]);

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Guardar"), button -> save())
                .dimensions(x, 48 + 8 * 22, w / 2 - 2, 20)
                .build());

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Cancelar"), button -> close())
                .dimensions(x + w / 2 + 2, 48 + 8 * 22, w / 2 - 2, 20)
                .build());
    }

    private void save() {
        StringBuilder code = new StringBuilder();

        for (TextFieldWidget line : lines) {
            String value = line.getText().trim();

            if (!value.isEmpty()) {
                if (code.length() > 0) code.append('\n');
                code.append(value);
            }
        }

        String program = code.toString();

        if (program.length() > GadgetProgram.MAX_LENGTH) {
            status = "El programa es demasiado largo.";
            return;
        }

        onSave.accept(program);
        client.setScreen(parent);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        for (TextFieldWidget line : lines) {
            if (line.charTyped(chr, modifiers)) return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        for (TextFieldWidget line : lines) {
            if (line.keyPressed(keyCode, scanCode, modifiers)) return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void render(
            DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);

        context.drawCenteredTextWithShadow(
                textRenderer, title, width / 2, 20, 0xFFFFFF);

        context.drawCenteredTextWithShadow(
                textRenderer,
                "Una instrucción por línea",
                width / 2, 34, 0xAAAAAA);

        for (TextFieldWidget line : lines) {
            line.render(context, mouseX, mouseY, delta);
        }

        if (!status.isEmpty()) {
            context.drawCenteredTextWithShadow(
                    textRenderer, status, width / 2, height - 20, 0xFF5555);
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
