package com.gadgetworks.client;

import com.gadgetworks.Gadgets;
import java.util.Arrays;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.render.DiffuseLighting;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RotationAxis;

public class GadgetEditorScreen extends Screen {
    private final BlockPos pos;
    private final byte[] voxels = new byte[Gadgets.VOLUME];
    private int layer = 0;
    private int piece = 1;          // 1..7
    private boolean erase = false;
    private boolean asBlock = true;
    private float yaw = 35f, pitch = 25f;
    private String status = "";

    private int gx, gy, cell, rx, rw, pvx, pvy, pvw, pvh, swX, swY, sw;

    public GadgetEditorScreen(BlockPos pos) {
        super(Text.literal("Mesa de Gadgets"));
        this.pos = pos;
    }

    @Override
    protected void init() {
        cell = Math.max(4, Math.min((height - 50) / 16, (width / 2 - 20) / 16));
        gx = 10; gy = 24;
        rx = gx + cell * 16 + 12;
        rw = width - rx - 10;
        pvx = rx; pvy = 24; pvw = rw; pvh = Math.max(30, height - 112);
        sw = Math.max(10, Math.min(24, rw / 7 - 2));
        swX = rx; swY = pvy + pvh + 4;

        int by1 = swY + sw + 6;
        int by2 = by1 + 22;
        int bw = rw / 4 - 2;

        addDrawableChild(ButtonWidget.builder(Text.literal("Capa -"), b -> layer = Math.max(0, layer - 1))
                .dimensions(rx, by1, bw, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Capa +"), b -> layer = Math.min(15, layer + 1))
                .dimensions(rx + (bw + 2), by1, bw, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(erase ? "Borrar" : "Pintar"), b -> {
                    erase = !erase;
                    b.setMessage(Text.literal(erase ? "Borrar" : "Pintar"));
                }).dimensions(rx + 2 * (bw + 2), by1, bw, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Limpiar"), b -> Arrays.fill(voxels, (byte) 0))
                .dimensions(rx + 3 * (bw + 2), by1, bw, 20).build());

        int bw3 = rw / 3 - 2;
        addDrawableChild(ButtonWidget.builder(Text.literal(asBlock ? "Sale: Bloque" : "Sale: Item"), b -> {
                    asBlock = !asBlock;
                    b.setMessage(Text.literal(asBlock ? "Sale: Bloque" : "Sale: Item"));
                }).dimensions(rx, by2, bw3, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Crear"), b -> create())
                .dimensions(rx + (bw3 + 2), by2, bw3, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Cerrar"), b -> close())
                .dimensions(rx + 2 * (bw3 + 2), by2, bw3, 20).build());
    }

    private void create() {
        if (Gadgets.count(voxels) == 0) { status = "El gadget esta vacio."; return; }
        if (!Gadgets.isConnected(voxels)) { status = "Hay piezas sueltas: unelas con pegamento."; return; }
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeBlockPos(pos);
        buf.writeBoolean(asBlock);
        buf.writeByteArray(voxels);
        ClientPlayNetworking.send(Gadgets.CREATE, buf);
        close();
    }

    @Override
    public boolean shouldPause() { return false; }

    // ---------- Entrada ----------
    private boolean paintAt(double mx, double my, int button) {
        int cx = (int) Math.floor((mx - gx) / cell);
        int cz = (int) Math.floor((my - gy) / cell);
        if (cx < 0 || cz < 0 || cx > 15 || cz > 15) return false;
        boolean er = erase || button == 1;
        voxels[Gadgets.idx(cx, layer, cz)] = er ? 0 : (byte) piece;
        status = "";
        return true;
    }

    private boolean inPreview(double mx, double my) {
        return mx >= pvx && mx < pvx + pvw && my >= pvy && my < pvy + pvh;
    }

    private int swatchAt(double mx, double my) {
        int col = (int) Math.floor((mx - swX) / (sw + 2));
        if (col < 0 || col >= Gadgets.PIECES || my < swY || my >= swY + sw) return -1;
        if (mx - swX - col * (sw + 2) >= sw) return -1;
        return col;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        if (paintAt(mx, my, button)) return true;
        int s = swatchAt(mx, my);
        if (s >= 0) {
            piece = s + 1;
            erase = false;
            clearAndInit();
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (paintAt(mx, my, button)) return true;
        if (inPreview(mx, my)) {
            yaw += (float) dx * 1.2f;
            pitch = Math.max(-89f, Math.min(89f, pitch + (float) dy * 1.2f));
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double amount) {
        layer = Math.max(0, Math.min(15, layer + (amount > 0 ? 1 : -1)));
        return true;
    }

    // ---------- Dibujo ----------
    private static void outline(DrawContext c, int x, int y, int w, int h, int argb) {
        c.fill(x, y, x + w, y + 1, argb);
        c.fill(x, y + h - 1, x + w, y + h, argb);
        c.fill(x, y, x + 1, y + h, argb);
        c.fill(x + w - 1, y, x + w, y + h, argb);
    }

    private static void icon(DrawContext c, int p, int x, int y, int w, int h) {
        c.drawTexture(GadgetRenderer.texture(p), x, y, w, h, 0f, 0f, 16, 16, 16, 16);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        renderBackground(ctx);
        ctx.drawTextWithShadow(textRenderer, "Mesa de Gadgets", gx, 8, 0xFFFFFF);
        int n = Gadgets.count(voxels);
        ctx.drawTextWithShadow(textRenderer, "Piezas: " + n + "  Coste: " + Gadgets.cost(n) + " hierro", rx, 8, 0xFFD060);

        // Cuadricula de la capa actual
        for (int z = 0; z < 16; z++) {
            for (int x = 0; x < 16; x++) {
                int px = gx + x * cell, pz = gy + z * cell;
                int c = voxels[Gadgets.idx(x, layer, z)];
                ctx.fill(px, pz, px + cell - 1, pz + cell - 1, ((x + z) & 1) == 0 ? 0xFF2B2B2B : 0xFF343434);
                if (c > 0) {
                    icon(ctx, (c - 1) % Gadgets.PIECES, px, pz, cell - 1, cell - 1);
                } else if (layer > 0) {
                    int b = voxels[Gadgets.idx(x, layer - 1, z)];
                    if (b > 0) {
                        icon(ctx, (b - 1) % Gadgets.PIECES, px, pz, cell - 1, cell - 1);
                        ctx.fill(px, pz, px + cell - 1, pz + cell - 1, 0xC0101010);
                    }
                }
            }
        }
        ctx.drawTextWithShadow(textRenderer,
                "Capa Y: " + layer + "/15   Pieza: " + Gadgets.NAMES[piece - 1], gx, gy + 16 * cell + 4, 0xFFFFFF);
        if (!status.isEmpty())
            ctx.drawTextWithShadow(textRenderer, status, gx, gy + 16 * cell + 16, 0xFF6060);

        // Vista previa 3D
        ctx.fill(pvx, pvy, pvx + pvw, pvy + pvh, 0xFF1A1A1A);
        outline(ctx, pvx, pvy, pvw, pvh, 0xFF555555);
        ctx.enableScissor(pvx + 1, pvy + 1, pvx + pvw - 1, pvy + pvh - 1);
        VertexConsumerProvider.Immediate imm = client.getBufferBuilders().getEntityVertexConsumers();
        MatrixStack m = ctx.getMatrices();
        float s = Math.min(pvw, pvh) * 0.5f;
        m.push();
        m.translate(pvx + pvw / 2f, pvy + pvh / 2f, 100f);
        m.scale(s, -s, s);
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(pitch));
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(yaw));
        m.translate(-0.5f, -0.5f, -0.5f);
        DiffuseLighting.enableGuiDepthLighting();
        GadgetRenderer.render(voxels, m, imm, LightmapTextureManager.MAX_LIGHT_COORDINATE, OverlayTexture.DEFAULT_UV);
        imm.draw();
        m.pop();
        ctx.disableScissor();

        // Selector de piezas
        for (int i = 0; i < Gadgets.PIECES; i++) {
            int x = swX + i * (sw + 2);
            ctx.fill(x - 1, swY - 1, x + sw + 1, swY + sw + 1, piece == i + 1 && !erase ? 0xFFFFFFFF : 0xFF444444);
            ctx.fill(x, swY, x + sw, swY + sw, 0xFF202020);
            icon(ctx, i, x, swY, sw, sw);
        }

        super.render(ctx, mx, my, delta);

        int hover = swatchAt(mx, my);
        if (hover >= 0) ctx.drawTooltip(textRenderer, Text.literal(Gadgets.NAMES[hover]), mx, my);
    }
}
