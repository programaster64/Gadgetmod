package com.gadgetworks.client;

import com.gadgetworks.GadgetBlockEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;

public class GadgetBER implements BlockEntityRenderer<GadgetBlockEntity> {
    @Override
    public void render(GadgetBlockEntity be, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vcp, int light, int overlay) {
        GadgetRenderer.render(be.getVoxels(), matrices, vcp, light, overlay);
    }
}
