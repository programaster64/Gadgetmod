package com.gadgetworks.client;

import com.gadgetworks.Gadgets;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** Dibuja la cuadricula de 16x16x16 como cubos dentro del cubo unidad (0..1). */
public final class GadgetRenderer {
    private static final Identifier TEX = new Identifier("minecraft", "textures/block/white_concrete.png");

    private GadgetRenderer() {}

    public static void render(byte[] v, MatrixStack m, VertexConsumerProvider vcp, int light, int overlay) {
        if (v == null || v.length != Gadgets.VOLUME) return;
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(TEX));
        MatrixStack.Entry e = m.peek();
        Matrix4f pm = e.getPositionMatrix();
        Matrix3f nm = e.getNormalMatrix();
        final float u = 1f / 16f;

        for (int y = 0; y < 16; y++) {
            for (int z = 0; z < 16; z++) {
                for (int x = 0; x < 16; x++) {
                    int c = v[Gadgets.idx(x, y, z)];
                    if (c == 0) continue;
                    int col = Gadgets.COLORS[(c - 1) & 15];
                    float r = ((col >> 16) & 255) / 255f;
                    float g = ((col >> 8) & 255) / 255f;
                    float b = (col & 255) / 255f;
                    float x0 = x * u, x1 = x0 + u, y0 = y * u, y1 = y0 + u, z0 = z * u, z1 = z0 + u;

                    if (!Gadgets.solid(v, x, y + 1, z))
                        quad(vc, pm, nm, new float[]{x0,y1,z0, x0,y1,z1, x1,y1,z1, x1,y1,z0}, 0, 1, 0, r, g, b, 1.00f, light, overlay);
                    if (!Gadgets.solid(v, x, y - 1, z))
                        quad(vc, pm, nm, new float[]{x0,y0,z0, x1,y0,z0, x1,y0,z1, x0,y0,z1}, 0, -1, 0, r, g, b, 0.55f, light, overlay);
                    if (!Gadgets.solid(v, x, y, z - 1))
                        quad(vc, pm, nm, new float[]{x1,y0,z0, x0,y0,z0, x0,y1,z0, x1,y1,z0}, 0, 0, -1, r, g, b, 0.80f, light, overlay);
                    if (!Gadgets.solid(v, x, y, z + 1))
                        quad(vc, pm, nm, new float[]{x0,y0,z1, x1,y0,z1, x1,y1,z1, x0,y1,z1}, 0, 0, 1, r, g, b, 0.80f, light, overlay);
                    if (!Gadgets.solid(v, x - 1, y, z))
                        quad(vc, pm, nm, new float[]{x0,y0,z0, x0,y0,z1, x0,y1,z1, x0,y1,z0}, -1, 0, 0, r, g, b, 0.65f, light, overlay);
                    if (!Gadgets.solid(v, x + 1, y, z))
                        quad(vc, pm, nm, new float[]{x1,y0,z1, x1,y0,z0, x1,y1,z0, x1,y1,z1}, 1, 0, 0, r, g, b, 0.65f, light, overlay);
                }
            }
        }
    }

    private static final float[] UV = {0, 0, 0, 1, 1, 1, 1, 0};

    private static void quad(VertexConsumer vc, Matrix4f pm, Matrix3f nm, float[] p,
                             float nx, float ny, float nz, float r, float g, float b, float shade,
                             int light, int overlay) {
        for (int i = 0; i < 4; i++) {
            vc.vertex(pm, p[i * 3], p[i * 3 + 1], p[i * 3 + 2])
                    .color(r * shade, g * shade, b * shade, 1f)
                    .texture(UV[i * 2], UV[i * 2 + 1])
                    .overlay(overlay)
                    .light(light)
                    .normal(nm, nx, ny, nz)
                    .next();
        }
    }
}
