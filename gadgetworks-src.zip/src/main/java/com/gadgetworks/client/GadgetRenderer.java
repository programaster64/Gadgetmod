package com.gadgetworks.client;

import com.gadgetworks.Gadgets;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** Dibuja la cuadricula de 16x16x16 como cubos texturizados dentro del cubo unidad (0..1). */
public final class GadgetRenderer {
    private static final Identifier[] TEX = new Identifier[Gadgets.PIECES];
    static {
        for (int i = 0; i < Gadgets.PIECES; i++)
            TEX[i] = new Identifier(Gadgets.ID, "textures/block/piece_" + Gadgets.PIECE_IDS[i] + ".png");
    }

    private GadgetRenderer() {}

    public static Identifier texture(int piece) { return TEX[piece]; }

    public static void render(byte[] v, MatrixStack m, VertexConsumerProvider vcp, int light, int overlay) {
        if (v == null || v.length != Gadgets.VOLUME) return;
        boolean[] present = new boolean[Gadgets.PIECES];
        for (byte b : v) if (b > 0) present[(b - 1) % Gadgets.PIECES] = true;

        MatrixStack.Entry e = m.peek();
        Matrix4f pm = e.getPositionMatrix();
        Matrix3f nm = e.getNormalMatrix();
        final float u = 1f / 16f;

        for (int p = 0; p < Gadgets.PIECES; p++) {
            if (!present[p]) continue;
            RenderLayer layer = p == Gadgets.GLUE
                    ? RenderLayer.getEntityTranslucent(TEX[p])
                    : RenderLayer.getEntityCutoutNoCull(TEX[p]);
            VertexConsumer vc = vcp.getBuffer(layer);

            for (int y = 0; y < 16; y++) {
                for (int z = 0; z < 16; z++) {
                    for (int x = 0; x < 16; x++) {
                        int c = v[Gadgets.idx(x, y, z)];
                        if (c <= 0 || (c - 1) % Gadgets.PIECES != p) continue;
                        float x0 = x * u, x1 = x0 + u, y0 = y * u, y1 = y0 + u, z0 = z * u, z1 = z0 + u;

                        if (!Gadgets.solid(v, x, y + 1, z))
                            quad(vc, pm, nm, new float[]{x0,y1,z0, x0,y1,z1, x1,y1,z1, x1,y1,z0},
                                    new float[]{x0,z0, x0,z1, x1,z1, x1,z0}, 0, 1, 0, 1.00f, light, overlay);
                        if (!Gadgets.solid(v, x, y - 1, z))
                            quad(vc, pm, nm, new float[]{x0,y0,z0, x1,y0,z0, x1,y0,z1, x0,y0,z1},
                                    new float[]{x0,z0, x1,z0, x1,z1, x0,z1}, 0, -1, 0, 0.55f, light, overlay);
                        if (!Gadgets.solid(v, x, y, z - 1))
                            quad(vc, pm, nm, new float[]{x1,y0,z0, x0,y0,z0, x0,y1,z0, x1,y1,z0},
                                    new float[]{x1,y0, x0,y0, x0,y1, x1,y1}, 0, 0, -1, 0.80f, light, overlay);
                        if (!Gadgets.solid(v, x, y, z + 1))
                            quad(vc, pm, nm, new float[]{x0,y0,z1, x1,y0,z1, x1,y1,z1, x0,y1,z1},
                                    new float[]{x0,y0, x1,y0, x1,y1, x0,y1}, 0, 0, 1, 0.80f, light, overlay);
                        if (!Gadgets.solid(v, x - 1, y, z))
                            quad(vc, pm, nm, new float[]{x0,y0,z0, x0,y0,z1, x0,y1,z1, x0,y1,z0},
                                    new float[]{z0,y0, z1,y0, z1,y1, z0,y1}, -1, 0, 0, 0.65f, light, overlay);
                        if (!Gadgets.solid(v, x + 1, y, z))
                            quad(vc, pm, nm, new float[]{x1,y0,z1, x1,y0,z0, x1,y1,z0, x1,y1,z1},
                                    new float[]{z1,y0, z0,y0, z0,y1, z1,y1}, 1, 0, 0, 0.65f, light, overlay);
                    }
                }
            }
        }
    }

    /** Renderiza un gadget como objeto, centrando su volumen en el origen de la mano. */
    public static void renderItem(byte[] voxels, MatrixStack matrices,
                                  VertexConsumerProvider consumers, int light, int overlay) {
        matrices.push();
        matrices.translate(-0.5, -0.5, -0.5);
        render(voxels, matrices, consumers, light, overlay);
        matrices.pop();
    }

    private static void quad(VertexConsumer vc, Matrix4f pm, Matrix3f nm, float[] p, float[] uv,
                             float nx, float ny, float nz, float shade, int light, int overlay) {
        for (int i = 0; i < 4; i++) {
            vc.vertex(pm, p[i * 3], p[i * 3 + 1], p[i * 3 + 2])
                    .color(shade, shade, shade, 1f)
                    .texture(uv[i * 2], uv[i * 2 + 1])
                    .overlay(overlay)
                    .light(light)
                    .normal(nm, nx, ny, nz)
                    .next();
        }
    }
}
