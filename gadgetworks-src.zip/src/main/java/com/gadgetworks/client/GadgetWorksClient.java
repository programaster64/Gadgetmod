package com.gadgetworks.client;

import com.gadgetworks.GadgetWorkbenchBlock;
import com.gadgetworks.Gadgets;
import com.gadgetworks.ModBlocks;
import com.gadgetworks.ModItems;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactories;

public class GadgetWorksClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        GadgetWorkbenchBlock.OPEN_HOOK = pos -> MinecraftClient.getInstance().setScreen(new GadgetEditorScreen(pos));

        BlockEntityRendererFactories.register(ModBlocks.GADGET_BE, ctx -> new GadgetBER());

        BuiltinItemRendererRegistry.DynamicItemRenderer r = (stack, mode, matrices, vcp, light, overlay) ->
                GadgetRenderer.renderItem(Gadgets.readVoxels(stack), matrices, vcp, light, overlay);
        BuiltinItemRendererRegistry.INSTANCE.register(ModItems.GADGET, r);
        BuiltinItemRendererRegistry.INSTANCE.register(ModItems.GADGET_BLOCK, r);
    }
}
